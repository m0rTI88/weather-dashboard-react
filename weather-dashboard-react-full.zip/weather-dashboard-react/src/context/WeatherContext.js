
export const initialState = {
  city: 'London',
  unit: 'metric',
  weatherData: null,
  error: null,
};

export function weatherReducer(state, action) {
  switch (action.type) {
    case 'FETCH_WEATHER':
      return { ...state, weatherData: action.payload, error: null };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'CHANGE_CITY':
      return { ...state, city: action.payload };
    case 'TOGGLE_UNIT':
      return { ...state, unit: state.unit === 'metric' ? 'imperial' : 'metric' };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
}
