
export const toFahrenheit = (celsius) => (celsius * 9) / 5 + 32;

export const processForecastData = (list) => {
  const dailyData = {};

  list.forEach(({ dt_txt, main }) => {
    const date = dt_txt.split(' ')[0];
    if (!dailyData[date]) dailyData[date] = [];
    dailyData[date].push(main.temp);
  });

  return Object.entries(dailyData).map(([date, temps]) => ({
    date,
    min: Math.min(...temps),
    max: Math.max(...temps),
    avg: temps.reduce((a, b) => a + b, 0) / temps.length,
  }));
};
