
import React from 'react';

function WeatherDisplay({ data }) {
  const weather = data.list[0];
  return (
    <div>
      <h2>Current Weather</h2>
      <p>Temperature: {weather.main.temp}°</p>
      <p>Condition: {weather.weather[0].description}</p>
    </div>
  );
}

export default WeatherDisplay;
