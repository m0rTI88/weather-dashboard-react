
import React from 'react';
import { processForecastData } from '../utils/temperature';

function ForecastList({ forecast }) {
  const dailyForecasts = processForecastData(forecast);
  return (
    <div>
      <h3>5-Day Forecast</h3>
      {dailyForecasts.slice(0, 5).map((day) => (
        <div key={day.date}>
          <p>{day.date}</p>
          <p>Min: {day.min}° | Max: {day.max}° | Avg: {day.avg.toFixed(1)}°</p>
        </div>
      ))}
    </div>
  );
}

export default ForecastList;
