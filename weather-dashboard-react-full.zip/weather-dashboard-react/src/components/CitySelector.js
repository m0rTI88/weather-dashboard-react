
import React, { useState } from 'react';
import debounce from '../utils/debounce';

function CitySelector({ dispatch }) {
  const [input, setInput] = useState('');

  const handleChange = debounce((value) => {
    dispatch({ type: 'CHANGE_CITY', payload: value });
  }, 300);

  return (
    <input
      type="text"
      placeholder="Enter city name"
      onChange={(e) => {
        setInput(e.target.value);
        handleChange(e.target.value);
      }}
      value={input}
    />
  );
}

export default CitySelector;
