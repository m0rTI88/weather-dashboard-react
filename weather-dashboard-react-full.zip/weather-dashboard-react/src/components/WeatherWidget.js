
import React, { useReducer } from 'react';
import CitySelector from './CitySelector';
import WeatherDisplay from './WeatherDisplay';
import ForecastList from './ForecastList';
import { initialState, weatherReducer } from '../context/WeatherContext';
import useWeatherData from '../hooks/useWeatherData';

function WeatherWidget() {
  const [state, dispatch] = useReducer(weatherReducer, initialState);
  useWeatherData(state.city, state.unit, dispatch);

  return (
    <div>
      <CitySelector dispatch={dispatch} />
      {state.error && <p>{state.error}</p>}
      {state.weatherData && (
        <>
          <WeatherDisplay data={state.weatherData} />
          <ForecastList forecast={state.weatherData.list} />
        </>
      )}
    </div>
  );
}

export default WeatherWidget;
