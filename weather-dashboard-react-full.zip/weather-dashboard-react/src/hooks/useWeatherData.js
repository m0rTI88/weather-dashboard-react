
import { useEffect } from 'react';
import axios from 'axios';

const useWeatherData = (city, unit, dispatch) => {
  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await axios.get(
          \`https://api.openweathermap.org/data/2.5/forecast?q=\${city}&units=\${unit}&appid=\${process.env.REACT_APP_API_KEY}\`
        );
        dispatch({ type: 'FETCH_WEATHER', payload: response.data });
      } catch (error) {
        dispatch({ type: 'SET_ERROR', payload: 'Failed to fetch weather data' });
      }
    };

    fetchWeather();
  }, [city, unit]);
};

export default useWeatherData;
