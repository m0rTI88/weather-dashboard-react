
# Weather Dashboard React App

## Overview
This application is a weather data dashboard that displays and analyzes weather forecasts for multiple cities. It is built using React and demonstrates state management, component composition, and API integration.

## Features
- City search with debounce
- Current weather display
- 5-day forecast
- Temperature conversion (Celsius/Fahrenheit)
- Responsive design with light/dark mode
- Mock API support

## Setup

1. Clone the repo:
```bash
git clone https://github.com/yourusername/weather-dashboard-react.git
```

2. Install dependencies:
```bash
npm install
```

3. Add your OpenWeatherMap API key:
Create a `.env` file and add:
```
REACT_APP_API_KEY=your_api_key_here
```

4. Run the app:
```bash
npm start
```

## Folder Structure
- `components/` - UI components
- `hooks/` - Custom hooks like `useWeatherData`
- `context/` - Global context
- `utils/` - Helper functions (debounce, throttle, temperature conversion)
- `data/` - Mock data

## Performance
- Debounced search input
- API throttling
- Memoized components where necessary

## Testing
Basic test examples using Jest + React Testing Library

---
